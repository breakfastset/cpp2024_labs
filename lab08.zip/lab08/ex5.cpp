#include <iostream>
#include <string>
#include <stack>
#include <vector>
#include <deque>
#include <list>
#include <ctime>

template<typename T, typename Container, size_t size = 10000>
void test_stack(std::string message) {

	std::stack<T, Container> test;
	T element;

	clock_t t0 = clock();
	for (size_t i = 0; i < size; i++)
		test.push(element);

	clock_t t1 = clock();
	std::cout << message << " timing: " << (double)(t1 - t0) / CLOCKS_PER_SEC  << '\n';
}

int main() {

	// WRITE MAIN FUNCTION HERE

return 0;
}
